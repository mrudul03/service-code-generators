package com.service.content.faqbannercontent.domain;

import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import io.quarkus.mongodb.panache.PanacheMongoRepository;
import io.quarkus.mongodb.panache.PanacheQuery;
import io.quarkus.panache.common.Page;

@ApplicationScoped
public class FaqBannerContentRepository implements PanacheMongoRepository<FaqBannerContentEntity>{

}