package com.service.content.faqbannercontent.domain;

import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class FaqBannerContentMapper {

	//DomaintoEntity
	private Function<FaqBannerContent, FaqBannerContentEntity> mapFaqBannerContentToEntityFn = new 
			Function<FaqBannerContent, FaqBannerContentEntity>(){

				@Override
				public FaqBannerContentEntity apply(FaqBannerContent domain) {
					FaqBannerContentEntity entity = new FaqBannerContentEntity();
					entity.setBannerImage(domain.getBannerImage());
					entity.setHeaderText(domain.getHeaderText());
					entity.setMetaTitle(domain.getMetaTitle());
					entity.setMetaKeywords(domain.getMetaKeywords());
					entity.setMetaDescription(domain.getMetaDescription());
					entity.setInsertedDate(domain.getInsertedDate());
					
					return entity;
				}
		
	};
	
	//EntityToDomain
	private Function<FaqBannerContentEntity, FaqBannerContent> mapFaqBannerContentEntityToDomainFn = new 
			Function<FaqBannerContentEntity, FaqBannerContent>(){
			
				@Override
				public FaqBannerContent apply(FaqBannerContentEntity entity) {
					FaqBannerContent domain = FaqBannerContent.builder().buildFrom(entity).build();
					return domain;
				}
	};
	
	public FaqBannerContentEntity transformFaqBannerContentToEntity(FaqBannerContent model) {
		return this.mapFaqBannerContentToEntityFn.apply(model);
	}
	
	public FaqBannerContent transformFaqBannerContentEntityToDomain(FaqBannerContentEntity contract) {
		return this.mapFaqBannerContentEntityToDomainFn.apply(contract);
	}
}