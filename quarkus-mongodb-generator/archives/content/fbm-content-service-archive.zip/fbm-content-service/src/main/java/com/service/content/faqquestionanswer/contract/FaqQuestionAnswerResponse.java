package com.service.content.faqquestionanswer.contract;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;
import java.util.Date;



@Data
@AllArgsConstructor
@NoArgsConstructor
public class FaqQuestionAnswerResponse {
	private Integer categoryId;
	private Integer subCategoryId;
	private Integer subSubCategoryId;
	private String question;
	private String answer;
	private Timestamp insertedDate;
	
}