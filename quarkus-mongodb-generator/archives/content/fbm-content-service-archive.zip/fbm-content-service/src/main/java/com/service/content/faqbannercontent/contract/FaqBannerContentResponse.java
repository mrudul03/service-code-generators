package com.service.content.faqbannercontent.contract;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;
import java.util.Date;



@Data
@AllArgsConstructor
@NoArgsConstructor
public class FaqBannerContentResponse {
	private String bannerImage;
	private String headerText;
	private String metaTitle;
	private String metaKeywords;
	private String metaDescription;
	private Timestamp insertedDate;
	
}