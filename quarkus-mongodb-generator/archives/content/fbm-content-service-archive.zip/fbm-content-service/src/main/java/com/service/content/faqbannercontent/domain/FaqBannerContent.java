package com.service.content.faqbannercontent.domain;

import org.bson.types.ObjectId;
import lombok.Setter;
import lombok.Getter;
import java.util.List;
import java.util.ArrayList;
import lombok.extern.slf4j.Slf4j;
import com.service.content.faqbannercontent.contract.*;
import java.sql.Timestamp;
import java.time.LocalDate;


@Slf4j
public class FaqBannerContent {
    
    
    @Getter
    private ObjectId faqBannerContentId;
    
    @Getter
    private String bannerImage;
    @Getter
    private String headerText;
    @Getter
    private String metaTitle;
    @Getter
    private String metaKeywords;
    @Getter
    private String metaDescription;
    @Getter
    private Timestamp insertedDate;
    
    protected FaqBannerContent(){}
    
    public static FaqBannerContentBuilder builder() {
        return new FaqBannerContentBuilder();
    }
    
    public static class FaqBannerContentBuilder {
        
        private String bannerImage;
        public FaqBannerContentBuilder withBannerImage(final String bannerImage) {
            this.bannerImage = bannerImage;
            return this;
        }
        
        private String headerText;
        public FaqBannerContentBuilder withHeaderText(final String headerText) {
            this.headerText = headerText;
            return this;
        }
        
        private String metaTitle;
        public FaqBannerContentBuilder withMetaTitle(final String metaTitle) {
            this.metaTitle = metaTitle;
            return this;
        }
        
        private String metaKeywords;
        public FaqBannerContentBuilder withMetaKeywords(final String metaKeywords) {
            this.metaKeywords = metaKeywords;
            return this;
        }
        
        private String metaDescription;
        public FaqBannerContentBuilder withMetaDescription(final String metaDescription) {
            this.metaDescription = metaDescription;
            return this;
        }
        
        private Timestamp insertedDate;
        public FaqBannerContentBuilder withInsertedDate(final Timestamp insertedDate) {
            this.insertedDate = insertedDate;
            return this;
        }
        public FaqBannerContentBuilder buildFrom(FaqBannerContentResponse request) {
        	// TODO set all domain values
        	
        	return this;
        }
        
        
        public FaqBannerContentBuilder buildFrom(FaqBannerContentEntity entity) {
        	// TODO set all domain values
        	this.withBannerImage(entity.getBannerImage());
        	this.withHeaderText(entity.getHeaderText());
        	this.withMetaTitle(entity.getMetaTitle());
        	this.withMetaKeywords(entity.getMetaKeywords());
        	this.withMetaDescription(entity.getMetaDescription());
        	this.withInsertedDate(entity.getInsertedDate());
        	return this;
        }
        
        public FaqBannerContent build() {
            FaqBannerContent faqBannerContent = new FaqBannerContent();
            faqBannerContent.bannerImage = this.bannerImage;
            faqBannerContent.headerText = this.headerText;
            faqBannerContent.metaTitle = this.metaTitle;
            faqBannerContent.metaKeywords = this.metaKeywords;
            faqBannerContent.metaDescription = this.metaDescription;
            faqBannerContent.insertedDate = this.insertedDate;
            return faqBannerContent;
        }
        
        
        public FaqBannerContent build(ObjectId faqBannerContentId) {
            FaqBannerContent faqBannerContent = this.build();
            faqBannerContent.faqBannerContentId = faqBannerContentId;
            return faqBannerContent;
        }
        

        private List<String> validate(){
            List<String> errors = new ArrayList<>();
            // validate common fields
            
            log.info("Validated with errors count::"+errors.size());
            return errors;
        }
        
        private boolean isValidField(String field) {
            boolean bValid = true;
            if(null == field || field.isBlank() || field.isEmpty()) {
                bValid = false;
            }
            return bValid;
        }
        
        private String formatErrorsAsString(List<String> errors) {
            StringBuilder sbErrors = new StringBuilder();
            errors.forEach(sbErrors::append);
            return sbErrors.toString();
        }
        
   }
   
}