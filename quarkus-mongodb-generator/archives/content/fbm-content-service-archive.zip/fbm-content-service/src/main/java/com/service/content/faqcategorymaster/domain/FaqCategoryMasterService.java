package com.service.content.faqcategorymaster.domain;

import lombok.extern.slf4j.Slf4j;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.transaction.Transactional;
import com.service.content.faqbannercontent.contract.*;

@ApplicationScoped
@Slf4j
public class FaqCategoryMasterService {
	
	@Inject
	FaqCategoryMasterRepository faqCategoryMasterRepository;
	public FaqCategoryMaster getFaqBannerContent() {
		
		//TODO
		return null;
	}
	
}