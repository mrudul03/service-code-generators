package com.service.content.faqcategorymaster.domain;

import org.bson.types.ObjectId;
import lombok.Setter;
import lombok.Getter;
import java.util.List;
import java.util.ArrayList;
import lombok.extern.slf4j.Slf4j;
import com.service.content.faqcategorymaster.contract.*;
import java.sql.Timestamp;
import java.time.LocalDate;


@Slf4j
public class FaqCategoryMaster {
    
    
    @Getter
    private ObjectId faqCategoryMasterId;
    
    @Getter
    private String categoryName;
    @Getter
    private String iconImage;
    @Getter
    private Timestamp insertedDate;
    
    protected FaqCategoryMaster(){}
    
    public static FaqCategoryMasterBuilder builder() {
        return new FaqCategoryMasterBuilder();
    }
    
    public static class FaqCategoryMasterBuilder {
        
        private String categoryName;
        public FaqCategoryMasterBuilder withCategoryName(final String categoryName) {
            this.categoryName = categoryName;
            return this;
        }
        
        private String iconImage;
        public FaqCategoryMasterBuilder withIconImage(final String iconImage) {
            this.iconImage = iconImage;
            return this;
        }
        
        private Timestamp insertedDate;
        public FaqCategoryMasterBuilder withInsertedDate(final Timestamp insertedDate) {
            this.insertedDate = insertedDate;
            return this;
        }
        public FaqCategoryMasterBuilder buildFrom(FaqCategoryMasterResponse request) {
        	// TODO set all domain values
        	
        	return this;
        }
        
        
        public FaqCategoryMasterBuilder buildFrom(FaqCategoryMasterEntity entity) {
        	// TODO set all domain values
        	this.withCategoryName(entity.getCategoryName());
        	this.withIconImage(entity.getIconImage());
        	this.withInsertedDate(entity.getInsertedDate());
        	return this;
        }
        
        public FaqCategoryMaster build() {
            FaqCategoryMaster faqCategoryMaster = new FaqCategoryMaster();
            faqCategoryMaster.categoryName = this.categoryName;
            faqCategoryMaster.iconImage = this.iconImage;
            faqCategoryMaster.insertedDate = this.insertedDate;
            return faqCategoryMaster;
        }
        
        
        public FaqCategoryMaster build(ObjectId faqCategoryMasterId) {
            FaqCategoryMaster faqCategoryMaster = this.build();
            faqCategoryMaster.faqCategoryMasterId = faqCategoryMasterId;
            return faqCategoryMaster;
        }
        

        private List<String> validate(){
            List<String> errors = new ArrayList<>();
            // validate common fields
            
            log.info("Validated with errors count::"+errors.size());
            return errors;
        }
        
        private boolean isValidField(String field) {
            boolean bValid = true;
            if(null == field || field.isBlank() || field.isEmpty()) {
                bValid = false;
            }
            return bValid;
        }
        
        private String formatErrorsAsString(List<String> errors) {
            StringBuilder sbErrors = new StringBuilder();
            errors.forEach(sbErrors::append);
            return sbErrors.toString();
        }
        
   }
   
}