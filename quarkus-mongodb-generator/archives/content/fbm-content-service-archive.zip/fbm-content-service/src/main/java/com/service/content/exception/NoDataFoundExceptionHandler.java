package com.service.content.faqbannercontent.exception;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

public class NoDataFoundExceptionHandler implements ExceptionMapper<NoDataFoundException> {

	@Override
	public Response toResponse(NoDataFoundException exception) {
		return Response.status(Response.Status.NOT_FOUND).build();
	}
	

}