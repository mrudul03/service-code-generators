package com.service.content.faqquestionanswer.domain;

import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class FaqQuestionAnswerMapper {

	//DomaintoEntity
	private Function<FaqQuestionAnswer, FaqQuestionAnswerEntity> mapFaqQuestionAnswerToEntityFn = new 
			Function<FaqQuestionAnswer, FaqQuestionAnswerEntity>(){

				@Override
				public FaqQuestionAnswerEntity apply(FaqQuestionAnswer domain) {
					FaqQuestionAnswerEntity entity = new FaqQuestionAnswerEntity();
					entity.setCategoryId(domain.getCategoryId());
					entity.setSubCategoryId(domain.getSubCategoryId());
					entity.setSubSubCategoryId(domain.getSubSubCategoryId());
					entity.setQuestion(domain.getQuestion());
					entity.setAnswer(domain.getAnswer());
					entity.setInsertedDate(domain.getInsertedDate());
					
					return entity;
				}
		
	};
	
	//EntityToDomain
	private Function<FaqQuestionAnswerEntity, FaqQuestionAnswer> mapFaqQuestionAnswerEntityToDomainFn = new 
			Function<FaqQuestionAnswerEntity, FaqQuestionAnswer>(){
			
				@Override
				public FaqQuestionAnswer apply(FaqQuestionAnswerEntity entity) {
					FaqQuestionAnswer domain = FaqQuestionAnswer.builder().buildFrom(entity).build();
					return domain;
				}
	};
	
	public FaqQuestionAnswerEntity transformFaqQuestionAnswerToEntity(FaqQuestionAnswer model) {
		return this.mapFaqQuestionAnswerToEntityFn.apply(model);
	}
	
	public FaqQuestionAnswer transformFaqQuestionAnswerEntityToDomain(FaqQuestionAnswerEntity contract) {
		return this.mapFaqQuestionAnswerEntityToDomainFn.apply(contract);
	}
}