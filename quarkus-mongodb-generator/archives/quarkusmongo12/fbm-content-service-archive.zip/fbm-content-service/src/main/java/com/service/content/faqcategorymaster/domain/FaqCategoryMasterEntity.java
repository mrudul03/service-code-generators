package com.service.content.faqcategorymaster.domain;

import org.bson.types.ObjectId;
import lombok.Setter;
import lombok.Getter;
import java.util.List;
import java.util.ArrayList;
import lombok.extern.slf4j.Slf4j;
import org.bson.types.ObjectId;
import io.quarkus.mongodb.panache.MongoEntity;
import lombok.Data;
import java.sql.Timestamp;
import java.time.LocalDate;


@Data
@Slf4j
@MongoEntity(collection="FaqCategoryMasterEntity")
public class FaqCategoryMasterEntity {

	public FaqCategoryMasterEntity(){}
    
    
    private ObjectId faqCategoryMasterEntityId;
    
    private String categoryName;
    private String iconImage;
    private Timestamp insertedDate;
}