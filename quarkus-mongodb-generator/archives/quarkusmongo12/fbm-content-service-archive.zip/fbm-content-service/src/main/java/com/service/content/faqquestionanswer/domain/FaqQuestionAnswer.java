package com.service.content.faqquestionanswer.domain;

import org.bson.types.ObjectId;
import lombok.Setter;
import lombok.Getter;
import java.util.List;
import java.util.ArrayList;
import lombok.extern.slf4j.Slf4j;
import com.service.content.faqquestionanswer.contract.*;
import java.sql.Timestamp;
import java.time.LocalDate;


@Slf4j
public class FaqQuestionAnswer {
    
    
    @Getter
    private ObjectId faqQuestionAnswerId;
    
    @Getter
    private Integer categoryId;
    @Getter
    private Integer subCategoryId;
    @Getter
    private Integer subSubCategoryId;
    @Getter
    private String question;
    @Getter
    private String answer;
    @Getter
    private Timestamp insertedDate;
    
    protected FaqQuestionAnswer(){}
    
    public static FaqQuestionAnswerBuilder builder() {
        return new FaqQuestionAnswerBuilder();
    }
    
    public static class FaqQuestionAnswerBuilder {
        
        private Integer categoryId;
        public FaqQuestionAnswerBuilder withCategoryId(final Integer categoryId) {
            this.categoryId = categoryId;
            return this;
        }
        
        private Integer subCategoryId;
        public FaqQuestionAnswerBuilder withSubCategoryId(final Integer subCategoryId) {
            this.subCategoryId = subCategoryId;
            return this;
        }
        
        private Integer subSubCategoryId;
        public FaqQuestionAnswerBuilder withSubSubCategoryId(final Integer subSubCategoryId) {
            this.subSubCategoryId = subSubCategoryId;
            return this;
        }
        
        private String question;
        public FaqQuestionAnswerBuilder withQuestion(final String question) {
            this.question = question;
            return this;
        }
        
        private String answer;
        public FaqQuestionAnswerBuilder withAnswer(final String answer) {
            this.answer = answer;
            return this;
        }
        
        private Timestamp insertedDate;
        public FaqQuestionAnswerBuilder withInsertedDate(final Timestamp insertedDate) {
            this.insertedDate = insertedDate;
            return this;
        }
        public FaqQuestionAnswerBuilder buildFrom(FaqQuestionAnswerResponse request) {
        	// TODO set all domain values
        	return this;
        }
        
        
        public FaqQuestionAnswerBuilder buildFrom(FaqQuestionAnswerEntity entity) {
        	// TODO set all domain values
        	this.withCategoryId(entity.getCategoryId());
        	this.withSubCategoryId(entity.getSubCategoryId());
        	this.withSubSubCategoryId(entity.getSubSubCategoryId());
        	this.withQuestion(entity.getQuestion());
        	this.withAnswer(entity.getAnswer());
        	this.withInsertedDate(entity.getInsertedDate());
        	return this;
        }
        
        public FaqQuestionAnswer build() {
            FaqQuestionAnswer faqQuestionAnswer = new FaqQuestionAnswer();
            faqQuestionAnswer.categoryId = this.categoryId;
            faqQuestionAnswer.subCategoryId = this.subCategoryId;
            faqQuestionAnswer.subSubCategoryId = this.subSubCategoryId;
            faqQuestionAnswer.question = this.question;
            faqQuestionAnswer.answer = this.answer;
            faqQuestionAnswer.insertedDate = this.insertedDate;
            return faqQuestionAnswer;
        }
        
        
        public FaqQuestionAnswer build(ObjectId faqQuestionAnswerId) {
            FaqQuestionAnswer faqQuestionAnswer = this.build();
            faqQuestionAnswer.faqQuestionAnswerId = faqQuestionAnswerId;
            return faqQuestionAnswer;
        }
        

        private List<String> validate(){
            List<String> errors = new ArrayList<>();
            // validate common fields
            
            log.info("Validated with errors count::"+errors.size());
            return errors;
        }
        
        private boolean isValidField(String field) {
            boolean bValid = true;
            if(null == field || field.isBlank() || field.isEmpty()) {
                bValid = false;
            }
            return bValid;
        }
        
        private String formatErrorsAsString(List<String> errors) {
            StringBuilder sbErrors = new StringBuilder();
            errors.forEach(sbErrors::append);
            return sbErrors.toString();
        }
        
   }
   
}