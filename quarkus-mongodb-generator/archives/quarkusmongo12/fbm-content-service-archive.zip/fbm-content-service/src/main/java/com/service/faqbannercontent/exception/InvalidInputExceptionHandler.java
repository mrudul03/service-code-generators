package com.service.faqbannercontent.exception;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

public class InvalidInputExceptionHandler implements ExceptionMapper<InvalidInputException> {

	@Override
	public Response toResponse(InvalidInputException exception) {
		return Response.status(Response.Status.BAD_REQUEST).build();
	}
	

}