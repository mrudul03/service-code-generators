package com.service.content.faqcategorymaster.domain;

import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class FaqCategoryMasterMapper {

	//DomaintoEntity
	private Function<FaqCategoryMaster, FaqCategoryMasterEntity> mapFaqCategoryMasterToEntityFn = new 
			Function<FaqCategoryMaster, FaqCategoryMasterEntity>(){

				@Override
				public FaqCategoryMasterEntity apply(FaqCategoryMaster domain) {
					FaqCategoryMasterEntity entity = new FaqCategoryMasterEntity();
					entity.setCategoryName(domain.getCategoryName());
					entity.setIconImage(domain.getIconImage());
					entity.setInsertedDate(domain.getInsertedDate());
					
					return entity;
				}
		
	};
	
	//EntityToDomain
	private Function<FaqCategoryMasterEntity, FaqCategoryMaster> mapFaqCategoryMasterEntityToDomainFn = new 
			Function<FaqCategoryMasterEntity, FaqCategoryMaster>(){
			
				@Override
				public FaqCategoryMaster apply(FaqCategoryMasterEntity entity) {
					FaqCategoryMaster domain = FaqCategoryMaster.builder().buildFrom(entity).build();
					return domain;
				}
	};
	
	public FaqCategoryMasterEntity transformFaqCategoryMasterToEntity(FaqCategoryMaster model) {
		return this.mapFaqCategoryMasterToEntityFn.apply(model);
	}
	
	public FaqCategoryMaster transformFaqCategoryMasterEntityToDomain(FaqCategoryMasterEntity contract) {
		return this.mapFaqCategoryMasterEntityToDomainFn.apply(contract);
	}
}