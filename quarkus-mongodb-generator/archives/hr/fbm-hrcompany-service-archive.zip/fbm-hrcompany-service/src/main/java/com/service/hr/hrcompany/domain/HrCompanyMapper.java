package com.service.hr.hrcompany.domain;

import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import javax.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class HrCompanyMapper {

	//DomaintoEntity
	private Function<HrCompany, HrCompanyEntity> mapHrCompanyToEntityFn = new 
			Function<HrCompany, HrCompanyEntity>(){

				@Override
				public HrCompanyEntity apply(HrCompany domain) {
					HrCompanyEntity entity = new HrCompanyEntity();
					entity.setCompanyName(domain.getCompanyName());
					entity.setLocalTimeZone(domain.getLocalTimeZone());
					entity.setLocalCurrency(domain.getLocalCurrency());
					entity.setCityId(domain.getCityId());
					entity.setCountryId(domain.getCountryId());
					entity.setContactPerson(domain.getContactPerson());
					entity.setEmails(domain.getEmails());
					entity.setIsDeleted(domain.getIsDeleted());
					entity.setInsertedUserId(domain.getInsertedUserId());
					entity.setInsertedDate(domain.getInsertedDate());
					entity.setUpdatedUserId(domain.getUpdatedUserId());
					entity.setUpdatedDate(domain.getUpdatedDate());
					
					return entity;
				}
		
	};
	
	//EntityToDomain
	private Function<HrCompanyEntity, HrCompany> mapHrCompanyEntityToDomainFn = new 
			Function<HrCompanyEntity, HrCompany>(){
			
				@Override
				public HrCompany apply(HrCompanyEntity entity) {
					HrCompany domain = HrCompany.builder().buildFrom(entity).build();
					return domain;
				}
	};
	
	public HrCompanyEntity transformHrCompanyToEntity(HrCompany model) {
		return this.mapHrCompanyToEntityFn.apply(model);
	}
	
	public HrCompany transformHrCompanyEntityToDomain(HrCompanyEntity contract) {
		return this.mapHrCompanyEntityToDomainFn.apply(contract);
	}
}