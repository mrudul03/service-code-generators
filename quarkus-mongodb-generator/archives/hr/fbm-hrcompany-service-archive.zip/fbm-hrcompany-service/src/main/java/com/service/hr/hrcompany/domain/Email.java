package com.service.hr.hrcompany.domain;

import org.bson.types.ObjectId;
import lombok.Setter;
import lombok.Getter;
import java.util.List;
import java.util.ArrayList;
import lombok.extern.slf4j.Slf4j;
import com.service.hr.hrcompany.contract.*;



@Slf4j
public class Email {
    
    
    @Getter
    private ObjectId emailId;
    
    @Getter
    private String type;
    @Getter
    private String emailaddress;
    
    protected Email(){}
    
    public static EmailBuilder builder() {
        return new EmailBuilder();
    }
    
    public static class EmailBuilder {
        
        private String type;
        public EmailBuilder withType(final String type) {
            this.type = type;
            return this;
        }
        
        private String emailaddress;
        public EmailBuilder withEmailaddress(final String emailaddress) {
            this.emailaddress = emailaddress;
            return this;
        }
        public EmailBuilder buildFrom(EmailDto request) {
        	// TODO set all domain values
        	
        	return this;
        }
        
        
        public EmailBuilder buildFrom(EmailEntity entity) {
        	// TODO set all domain values
        	this.withType(entity.getType());
        	this.withEmailaddress(entity.getEmailaddress());
        	return this;
        }
        
        public Email build() {
            Email email = new Email();
            email.type = this.type;
            email.emailaddress = this.emailaddress;
            return email;
        }
        
        
        public Email build(ObjectId emailId) {
            Email email = this.build();
            email.emailId = emailId;
            return email;
        }
        

        private List<String> validate(){
            List<String> errors = new ArrayList<>();
            // validate common fields
            
            log.info("Validated with errors count::"+errors.size());
            return errors;
        }
        
        private boolean isValidField(String field) {
            boolean bValid = true;
            if(null == field || field.isBlank() || field.isEmpty()) {
                bValid = false;
            }
            return bValid;
        }
        
        private String formatErrorsAsString(List<String> errors) {
            StringBuilder sbErrors = new StringBuilder();
            errors.forEach(sbErrors::append);
            return sbErrors.toString();
        }
        
   }
   
}