package com.service.hr.hrcompany.contract;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



import java.util.List;
import java.util.ArrayList;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class HrCompanyResponse {
	private String companyName;
	private String localTimeZone;
	private String localCurrency;
	private Integer cityId;
	private Integer countryId;
	private ContactPersonDto contactPerson;
	private List<EmailDto> emails;
	
}