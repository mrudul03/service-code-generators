package com.service.hr.hrcompany.domain;

import lombok.extern.slf4j.Slf4j;
import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.transaction.Transactional;
import com.service.hr.hrcompany.contract.*;

@ApplicationScoped
@Slf4j
public class HrCompanyService {
	
	@Inject
	HrCompanyRepository hrCompanyRepository;
	public HrCompany getHrCompany(Long hrCompanyId) {
		
		//TODO
		return null;
	}
	public HrCompany addHrCompany(HrCompanyRequest hrCompanyRequest) {
		
		//TODO
		return null;
	}
	public HrCompany deactivateHrCompany(Long hrCompanyId) {
		
		//TODO
		return null;
	}
	public HrCompany activateHrCompany(Long hrCompanyId) {
		
		//TODO
		return null;
	}
	public HrCompany updateHrCompany(HrCompanyRequest hrCompanyRequest,Long hrCompanyId) {
		
		//TODO
		return null;
	}
	public HrCompany deleteHrCompany(Long hrCompanyId) {
		
		//TODO
		return null;
	}
	
}