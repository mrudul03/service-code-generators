package com.service.hr.hrcompany.domain;

import org.bson.types.ObjectId;
import lombok.Setter;
import lombok.Getter;
import java.util.List;
import java.util.ArrayList;
import lombok.extern.slf4j.Slf4j;
import com.service.hr.hrcompany.contract.*;



@Slf4j
public class ContactPerson {
    
    
    @Getter
    private ObjectId contactPersonId;
    
    @Getter
    private String firstName;
    @Getter
    private String lastName;
    
    protected ContactPerson(){}
    
    public static ContactPersonBuilder builder() {
        return new ContactPersonBuilder();
    }
    
    public static class ContactPersonBuilder {
        
        private String firstName;
        public ContactPersonBuilder withFirstName(final String firstName) {
            this.firstName = firstName;
            return this;
        }
        
        private String lastName;
        public ContactPersonBuilder withLastName(final String lastName) {
            this.lastName = lastName;
            return this;
        }
        public ContactPersonBuilder buildFrom(ContactPersonDto request) {
        	// TODO set all domain values
        	
        	return this;
        }
        
        
        public ContactPersonBuilder buildFrom(ContactPersonEntity entity) {
        	// TODO set all domain values
        	this.withFirstName(entity.getFirstName());
        	this.withLastName(entity.getLastName());
        	return this;
        }
        
        public ContactPerson build() {
            ContactPerson contactPerson = new ContactPerson();
            contactPerson.firstName = this.firstName;
            contactPerson.lastName = this.lastName;
            return contactPerson;
        }
        
        
        public ContactPerson build(ObjectId contactPersonId) {
            ContactPerson contactPerson = this.build();
            contactPerson.contactPersonId = contactPersonId;
            return contactPerson;
        }
        

        private List<String> validate(){
            List<String> errors = new ArrayList<>();
            // validate common fields
            
            log.info("Validated with errors count::"+errors.size());
            return errors;
        }
        
        private boolean isValidField(String field) {
            boolean bValid = true;
            if(null == field || field.isBlank() || field.isEmpty()) {
                bValid = false;
            }
            return bValid;
        }
        
        private String formatErrorsAsString(List<String> errors) {
            StringBuilder sbErrors = new StringBuilder();
            errors.forEach(sbErrors::append);
            return sbErrors.toString();
        }
        
   }
   
}