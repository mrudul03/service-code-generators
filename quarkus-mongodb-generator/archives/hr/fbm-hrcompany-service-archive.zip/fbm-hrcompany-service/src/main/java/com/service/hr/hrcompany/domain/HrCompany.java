package com.service.hr.hrcompany.domain;

import org.bson.types.ObjectId;
import lombok.Setter;
import lombok.Getter;
import java.util.List;
import java.util.ArrayList;
import lombok.extern.slf4j.Slf4j;
import com.service.hr.hrcompany.contract.*;
import java.sql.Timestamp;
import java.time.LocalDate;


@Slf4j
public class HrCompany {
    
    
    @Getter
    private ObjectId hrCompanyId;
    
    @Getter
    private String companyName;
    @Getter
    private String localTimeZone;
    @Getter
    private String localCurrency;
    @Getter
    private Integer cityId;
    @Getter
    private Integer countryId;
    @Getter
    private ContactPerson contactPerson;
    @Getter
    private List<Email> emails;
    @Getter
    private Boolean isDeleted;
    @Getter
    private Long insertedUserId;
    @Getter
    private Timestamp insertedDate;
    @Getter
    private Long updatedUserId;
    @Getter
    private Timestamp updatedDate;
    
    protected HrCompany(){}
    
    public static HrCompanyBuilder builder() {
        return new HrCompanyBuilder();
    }
    
    public static class HrCompanyBuilder {
        
        private String companyName;
        public HrCompanyBuilder withCompanyName(final String companyName) {
            this.companyName = companyName;
            return this;
        }
        
        private String localTimeZone;
        public HrCompanyBuilder withLocalTimeZone(final String localTimeZone) {
            this.localTimeZone = localTimeZone;
            return this;
        }
        
        private String localCurrency;
        public HrCompanyBuilder withLocalCurrency(final String localCurrency) {
            this.localCurrency = localCurrency;
            return this;
        }
        
        private Integer cityId;
        public HrCompanyBuilder withCityId(final Integer cityId) {
            this.cityId = cityId;
            return this;
        }
        
        private Integer countryId;
        public HrCompanyBuilder withCountryId(final Integer countryId) {
            this.countryId = countryId;
            return this;
        }
        
        private ContactPerson contactPerson;
        public HrCompanyBuilder withContactPerson(final ContactPerson contactPerson) {
            this.contactPerson = contactPerson;
            return this;
        }
        
        private List<Email> emails;
        public HrCompanyBuilder withEmails(final List<Email> emails) {
            this.emails = emails;
            return this;
        }
        
        private Boolean isDeleted;
        public HrCompanyBuilder withIsDeleted(final Boolean isDeleted) {
            this.isDeleted = isDeleted;
            return this;
        }
        
        private Long insertedUserId;
        public HrCompanyBuilder withInsertedUserId(final Long insertedUserId) {
            this.insertedUserId = insertedUserId;
            return this;
        }
        
        private Timestamp insertedDate;
        public HrCompanyBuilder withInsertedDate(final Timestamp insertedDate) {
            this.insertedDate = insertedDate;
            return this;
        }
        
        private Long updatedUserId;
        public HrCompanyBuilder withUpdatedUserId(final Long updatedUserId) {
            this.updatedUserId = updatedUserId;
            return this;
        }
        
        private Timestamp updatedDate;
        public HrCompanyBuilder withUpdatedDate(final Timestamp updatedDate) {
            this.updatedDate = updatedDate;
            return this;
        }
        public HrCompanyBuilder buildFrom(HrCompanyRequest request) {
        	// TODO set all domain values
        	
        	return this;
        }
        
        
        public HrCompanyBuilder buildFrom(HrCompanyEntity entity) {
        	// TODO set all domain values
        	this.withCompanyName(entity.getCompanyName());
        	this.withLocalTimeZone(entity.getLocalTimeZone());
        	this.withLocalCurrency(entity.getLocalCurrency());
        	this.withCityId(entity.getCityId());
        	this.withCountryId(entity.getCountryId());
        	this.withContactPerson(entity.getContactPerson());
        	this.withEmails(entity.getEmails());
        	this.withIsDeleted(entity.getIsDeleted());
        	this.withInsertedUserId(entity.getInsertedUserId());
        	this.withInsertedDate(entity.getInsertedDate());
        	this.withUpdatedUserId(entity.getUpdatedUserId());
        	this.withUpdatedDate(entity.getUpdatedDate());
        	return this;
        }
        
        public HrCompany build() {
            HrCompany hrCompany = new HrCompany();
            hrCompany.companyName = this.companyName;
            hrCompany.localTimeZone = this.localTimeZone;
            hrCompany.localCurrency = this.localCurrency;
            hrCompany.cityId = this.cityId;
            hrCompany.countryId = this.countryId;
            hrCompany.contactPerson = this.contactPerson;
            hrCompany.emails = this.emails;
            hrCompany.isDeleted = this.isDeleted;
            hrCompany.insertedUserId = this.insertedUserId;
            hrCompany.insertedDate = this.insertedDate;
            hrCompany.updatedUserId = this.updatedUserId;
            hrCompany.updatedDate = this.updatedDate;
            return hrCompany;
        }
        
        
        public HrCompany build(ObjectId hrCompanyId) {
            HrCompany hrCompany = this.build();
            hrCompany.hrCompanyId = hrCompanyId;
            return hrCompany;
        }
        

        private List<String> validate(){
            List<String> errors = new ArrayList<>();
            // validate common fields
            
            log.info("Validated with errors count::"+errors.size());
            return errors;
        }
        
        private boolean isValidField(String field) {
            boolean bValid = true;
            if(null == field || field.isBlank() || field.isEmpty()) {
                bValid = false;
            }
            return bValid;
        }
        
        private String formatErrorsAsString(List<String> errors) {
            StringBuilder sbErrors = new StringBuilder();
            errors.forEach(sbErrors::append);
            return sbErrors.toString();
        }
        
   }
   
}