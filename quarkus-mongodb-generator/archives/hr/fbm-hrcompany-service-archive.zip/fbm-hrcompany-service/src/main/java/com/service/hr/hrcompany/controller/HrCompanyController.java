package com.service.hr.hrcompany.controller;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import lombok.extern.slf4j.Slf4j;
import com.service.hr.hrcompany.domain.*;
import com.service.hr.hrcompany.contract.*;

@Path("/api")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Slf4j
public class HrCompanyController {
	
	@Inject
	private HrCompanyService hrCompanyService;
	
	@GET
	@Path("/{hrCompanyId}")
	public HrCompanyResponse getHrCompany(@PathParam("hrCompanyId") Long hrCompanyId) {
		
		return new HrCompanyResponse ();
	}
	
	@POST
	@Path("/")
	public HrCompanyResponse addHrCompany( HrCompanyRequest request) {
		
		return new HrCompanyResponse ();
	}
	
	@PUT
	@Path("/{hrCompanyId}/deactivate")
	public HrCompanyResponse deactivateHrCompany(@PathParam("hrCompanyId") Long hrCompanyId) {
		
		return new HrCompanyResponse ();
	}
	
	@PUT
	@Path("/{hrCompanyId}/activate")
	public HrCompanyResponse activateHrCompany(@PathParam("hrCompanyId") Long hrCompanyId) {
		
		return new HrCompanyResponse ();
	}
	
	@PUT
	@Path("/{hrCompanyId}")
	public HrCompanyResponse updateHrCompany( HrCompanyRequest request,@PathParam("hrCompanyId") Long hrCompanyId) {
		
		return new HrCompanyResponse ();
	}
	
	@DELETE
	@Path("/{hrCompanyId}")
	public void deleteHrCompany(@PathParam("hrCompanyId") Long hrCompanyId) {
		
		;
	}
	
}