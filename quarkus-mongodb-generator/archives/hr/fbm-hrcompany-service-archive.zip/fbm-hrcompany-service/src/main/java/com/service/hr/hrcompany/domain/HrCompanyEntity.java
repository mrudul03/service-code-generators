package com.service.hr.hrcompany.domain;

import org.bson.types.ObjectId;
import lombok.Setter;
import lombok.Getter;
import java.util.List;
import java.util.ArrayList;
import lombok.extern.slf4j.Slf4j;
import org.bson.types.ObjectId;
import io.quarkus.mongodb.panache.MongoEntity;
import lombok.Data;
import java.sql.Timestamp;
import java.time.LocalDate;


@Data
@Slf4j
@MongoEntity(collection="HrCompanyEntity")
public class HrCompanyEntity {

	public HrCompanyEntity(){}
    
    
    private ObjectId hrCompanyEntityId;
    
    private String companyName;
    private String localTimeZone;
    private String localCurrency;
    private Integer cityId;
    private Integer countryId;
    private ContactPerson contactPerson;
    private List<Email> emails;
    private Boolean isDeleted;
    private Long insertedUserId;
    private Timestamp insertedDate;
    private Long updatedUserId;
    private Timestamp updatedDate;
}