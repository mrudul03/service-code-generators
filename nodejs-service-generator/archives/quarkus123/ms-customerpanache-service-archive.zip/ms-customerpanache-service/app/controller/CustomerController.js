const db = require("../models");
const Contact = db.contact;
const Email = db.email;
const Customer = db.customer;

// domain operations
exports.getCustomer = (req, res) => {
  // Validate request
  
  // Execute request
};
exports.addCustomer = (req, res) => {
  // Validate request
  
  // Execute request
};
exports.deactivateCustomer = (req, res) => {
  // Validate request
  
  // Execute request
};
exports.activateCustomer = (req, res) => {
  // Validate request
  
  // Execute request
};
exports.updateCustomer = (req, res) => {
  // Validate request
  
  // Execute request
};
exports.deleteCustomer = (req, res) => {
  // Validate request
  
  // Execute request
};

